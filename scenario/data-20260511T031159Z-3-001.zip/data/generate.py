"""
Synthetic citizen feedback dataset generator.

Produces ~320 emails over an 8-week window for the AI-Native Builder assessment.
The dataset is intentionally:
  - Realistic enough to feel like real ops work (Singapore civic context)
  - Varied across 12 topical clusters
  - Skewed in urgency: ~5% high, ~20% medium, ~75% low
  - Non-uniform in time: some clusters spike in certain weeks (trend signal)
  - Mixed in tone: complaints, suggestions, kudos, ambiguous

Run:
    python3 generate.py > citizen-feedback-emails.json

This file is committed alongside the resulting dataset so candidates can either
load the JSON directly OR regenerate / extend.
"""

import json
import random
from datetime import datetime, timedelta

random.seed(42)

ANCHOR = datetime(2026, 5, 4, 9, 0, 0)
WEEKS = 8
TOTAL_EMAILS = 320

NAMES = [
    "Tan Wei Ming", "Siti Nurhaliza", "Kumar Raj", "Lim Hui Min", "Ong Bee Choo",
    "Mohammed Iskandar", "Priya Devi", "Goh Kok Wei", "Lee Mei Ling", "Wong Jia Hui",
    "Chen Xiu Ying", "Ahmad Faizal", "Anita Singh", "Teo Boon Hock", "Ng Pei Shan",
    "Rajesh Pillai", "Fatimah Bte Hassan", "Koh Cheng Hwee", "Vincent Soh", "Cheryl Toh",
    "Anonymous", "Anonymous", "Anonymous",
]

CLUSTERS = {
    "transport": {
        "weight": 0.18,
        "trend": "rising",
        "subjects": [
            "MRT delay on {line} line again this morning",
            "Bus {bus_no} skipping stops at peak hour",
            "Feedback on the new bus interchange at {town}",
            "Severe overcrowding on {line} line",
            "Taxi refusing short trips at {town} MRT",
            "PHV driver took the long route",
            "Why is the {line} line breaking down weekly now?",
            "Suggestion: more feeder buses for {town}",
        ],
        "bodies": [
            "I was stuck on the {line} line for 35 minutes this morning. This is the third time this week. My kids were late for school and I was late for work. The announcements were useless — just 'train delay due to signal fault' on loop. Please do something.",
            "Bus {bus_no} has been skipping the {town} stop during peak hour. I've missed three appointments. The drivers say it's because the bus is full but the next one is 25 minutes away. This is unacceptable for a service we pay for.",
            "The new bus interchange at {town} is poorly designed. The bays are far apart, there's no shelter between them, and the wayfinding signs are confusing for elderly residents. My mother nearly missed her bus because she couldn't find the right bay.",
            "Have been taking the {line} line for 12 years. The reliability has dropped noticeably in the last 3 months. I track the delays — averaging 2 incidents a week now versus maybe 1 a month before. Something has changed and no one is being transparent about it.",
            "Took a taxi from {town} MRT at 11pm last night. The driver refused short trips outright and tried to charge a flat fare off-meter. Reported to LTA but heard nothing. This is a recurring problem at this stand.",
            "Quick suggestion — could we get more feeder bus frequency for {town} during evening peak? Currently 15-min intervals which feels long when buses pass you full.",
            "URGENT — train evacuation at {town} station this morning. Smoke in the tunnel. We were walked along the tracks. No staff communication for 20 minutes. Elderly passengers were panicking. This was genuinely dangerous and someone needs to explain what happened.",
        ],
    },
    "housing": {
        "weight": 0.14,
        "trend": "steady",
        "subjects": [
            "HDB lift breakdown at Block {blk}, {town}",
            "Water leak from upstairs unit — no response from town council",
            "BTO completion delay update?",
            "Feedback on the new HDB upgrading works",
            "Rodent issue in {town} estate",
            "Renovation noise outside permitted hours",
        ],
        "bodies": [
            "The lift at Block {blk} {town} has been down for 4 days. I am 78 years old and live on the 14th floor. Yesterday I could not go down to get groceries. My neighbour helped but this cannot continue. When will it be fixed?",
            "Water has been leaking from my ceiling for two weeks. I've contacted the town council three times. They told me to settle with the upstairs neighbour directly but he is not responding. The leak is now damaging my ceiling. Please help mediate.",
            "Any update on the BTO at {town}? We were told completion Q2 2026 but it's already May and we have no concrete date. We've been renting in the meantime and the costs are mounting. A clear update — even bad news — would help us plan.",
            "The HEIP works at our block have started. I just want to say the contractors have been polite and the noise has been within permitted hours. Appreciate that. Just one thing — could you put up more notices in Tamil and Malay too?",
            "Rats. Many rats. In the bin centre at our estate. I see them every evening. Reported to the town council last month and someone came once but they're back. We have young kids playing nearby and this is a real health concern.",
            "Renovation noise from the unit above us started at 6:45am Saturday. NEA hotline says renovation hours are 9am-5pm weekdays only. This has happened 3 weekends in a row. Need enforcement, not just guidelines.",
        ],
    },
    "healthcare": {
        "weight": 0.11,
        "trend": "rising",
        "subjects": [
            "Polyclinic wait time at {town} polyclinic",
            "Difficulty getting CHAS appointment",
            "Hospital A&E experience — feedback",
            "Mental health support access",
            "Vaccination appointment availability",
        ],
        "bodies": [
            "Went to {town} Polyclinic on Monday. 3 hour wait for a 5 minute consultation. The booking system said 30 min wait. The staff were apologetic but this is the third visit in a row. Is there a staffing problem we should know about?",
            "I'm a CHAS Blue card holder. Tried to book a GP appointment near {town} for 5 days running. Every clinic is either fully booked or not accepting new CHAS patients. What's the point of the card if I can't get an appointment?",
            "Took my elderly father to A&E last Tuesday night. We waited 6 hours before being seen. He was in significant pain. The triage said P3 but his condition turned out to be more serious. Suggesting a review of how P3 is assigned for elderly patients with comorbidities.",
            "I've been trying to access mental health support through the public system. The IMH wait is 8 weeks. CHAT has limited slots for adults. Private is $300/session and I can't afford it. The 'mental wellness initiatives' are all marketing — actual access is broken.",
            "URGENT: my elderly mother fell at home and we're at A&E. She's been waiting 4 hours with a possible hip fracture, no pain relief, no scan yet. Please escalate. {phone}",
            "Just wanted to thank the staff at {town} Polyclinic — saw Dr Lim today and she was thorough, kind, and explained everything clearly. Don't always send complaints. Good things happen too.",
        ],
    },
    "education": {
        "weight": 0.08,
        "trend": "falling",
        "subjects": [
            "Primary 1 registration outcome — appeal",
            "PSLE scoring concern",
            "Feedback on full SBB rollout",
            "School bus pricing increase",
            "MOE FAS application process",
        ],
        "bodies": [
            "We were not allocated a place in our preferred school despite living within 1km. The next school is 2.3km away. With both parents working this is a real logistical issue. Requesting a review of our case. Child's ID redacted but available.",
            "My child is in P6 this year. The PSLE AL system has reduced visible differentiation at the top — three students in his cohort with AL4 went to very different secondary schools. Could MOE clarify the affiliation tiebreaker logic publicly?",
            "Full SBB is now in its second year and from a parent's view things have settled. Wanted to share that the streaming-by-subject is working well for my Sec 1 daughter — she's taking H1 Math, G3 English. The flexibility is appreciated.",
            "School bus fees up 18% this year. The operator says fuel and driver wages. I get it but 18% in one year is a lot for a family with two kids. Is there any subsidy review for middle-income families coming?",
            "Tried to apply for MOE FAS. The online form crashes on Step 4 every time, both Chrome and Safari. Have screenshots. Called the hotline, was told 'we'll log a ticket.' Two weeks later, no update.",
        ],
    },
    "digital_services": {
        "weight": 0.10,
        "trend": "rising",
        "subjects": [
            "Singpass login failure on iOS",
            "MyInfo data outdated — how to update?",
            "LifeSG app crashing on startup",
            "IRAS portal — tax filing issue",
            "ICA passport renewal — Singpass error",
        ],
        "bodies": [
            "Singpass app keeps logging me out after the update last week. iOS 17.5, iPhone 14. Have to re-authenticate with fingerprint every single time I open the app. Used to work fine. Three friends with iPhones reporting the same.",
            "My MyInfo address shows my previous address even though I updated it on ICA two months ago. Tried to use it for a bank application and got rejected because the address didn't match my IC. The data sync between agencies is clearly broken.",
            "LifeSG app crashes immediately on launch after the latest update. Android 14, Samsung S23. Reinstalled, cleared cache, same issue. The bus arrival widget worked great before — now I have to use a third party app.",
            "Tried to file my tax return on IRAS this morning. Got a 'Session timeout' error after 30 min of inputting. Lost everything. Why doesn't the form save progress automatically in 2026?",
            "I tried to renew my passport via the ICA portal. Singpass authentication redirects in a loop. Tried 4 times. Eventually had to call the hotline — they were helpful but said it's a known issue with no ETA. Embarrassing for a Smart Nation.",
            "Wanted to say — the LifeSG bills feature is genuinely useful. I now pay my utilities, conservancy, and HDB loan in one place. Took a while to find but it's a quietly good piece of work. More of this please.",
        ],
    },
    "safety": {
        "weight": 0.06,
        "trend": "steady",
        "subjects": [
            "Pedestrian crossing at {town} — near miss",
            "Loitering and noise at void deck",
            "Cycling on pedestrian paths — enforcement?",
            "Suspicious activity at {town} park",
            "Streetlight outage on {street}",
        ],
        "bodies": [
            "Pedestrian crossing at the junction of {street} and {town} Ave is dangerous. Cars run the red on right-turn arrows. I almost got hit yesterday with my toddler in the stroller. Multiple incidents reported by neighbours over months. Please install a red-light camera.",
            "Group of teenagers gathering at the void deck of Block {blk} every night until 2-3am. Smoking, drinking, loud music. We've called the police three times. Officers come, they disperse, they're back the next night. We need a more sustained response.",
            "PMD and bicycle riders consistently using the pedestrian path at high speed along the park connector at {town}. The 'cyclists dismount' signs are ignored. An elderly resident was knocked down last month. When does enforcement actually happen?",
            "I saw a man taking photos of children at the playground in {town} park this evening. Approached him, he claimed he was photographing 'the architecture.' Reported to police, they took a statement. Wanted to flag this to NParks too — staff presence at playgrounds during after-school hours would help.",
            "Streetlight outside Block {blk} on {street} has been out for 11 days. It's pitch dark on that stretch. Already reported via OneService twice. When?",
            "URGENT — strong smell of gas at the void deck of Block {blk} {town}. Called SCDF. Writing here too in case the report gets buried. Don't smoke or use lights anywhere near.",
        ],
    },
    "environment": {
        "weight": 0.07,
        "trend": "falling",
        "subjects": [
            "Dengue cluster at {town} — update",
            "Cleanliness at {town} hawker centre",
            "Tree pruning request — overgrown branch",
            "Stray cats — sterilisation programme",
            "Plastic bag charge — feedback",
        ],
        "bodies": [
            "Dengue cluster declared at {town} two weeks ago. I see the NEA notices but I haven't seen any actual fogging in our area. What's the schedule? My neighbour just got diagnosed.",
            "The {town} hawker centre has been visibly dirty for weeks. Trays not cleared, floors sticky, pigeons inside. The cleaning contractor seems understaffed. Could NEA review the contract?",
            "There's an overgrown branch from the rain tree outside Block {blk} that's now touching my 8th floor window. Worried about falling branches in a storm. Reported to town council 3 weeks ago.",
            "Wanted to commend the TNRM programme at our estate — visibly fewer kittens this year compared to 2024 when there were litters everywhere. The volunteers are doing good work. Please continue funding this.",
            "The plastic bag charge has been in effect for a while now. Honestly it's working — I see fewer plastic bags everywhere. Small thing but a good policy. Thank you.",
            "Construction dust from the BTO site at {town} is blowing into our flats every afternoon. Reported to NEA, they said within permissible limits. The 'permissible limits' need updating — we can't open windows.",
        ],
    },
    "cost_of_living": {
        "weight": 0.07,
        "trend": "rising",
        "subjects": [
            "Conservancy charge increase",
            "Food prices at hawker centres — feedback",
            "GST voucher amount inadequate",
            "Childcare fees — review",
            "Electricity tariff",
        ],
        "bodies": [
            "Conservancy charge went up again. Third increase in two years. We're a working-class family in a 3-room flat. The CDC vouchers help but they don't offset the ongoing fee hikes. Where is the money going?",
            "Hawker prices are quietly creeping up everywhere. $4.50 for chicken rice is now the norm in town. I get inflation but the gap between hawker and food court is closing fast. Any policy levers being considered?",
            "Got my GST voucher this month. Appreciate it. But realistically, the amount covers maybe 2 weeks of additional grocery cost given current price levels. Please consider increasing the assistance tier for households with elderly dependents.",
            "Childcare fees for my 3-year-old just went up 7%. We're already paying $1,400/month after subsidies. The 'affordable preschool' framing is increasingly disconnected from reality. Please review the subsidy formula.",
            "Electricity bill jumped 22% this quarter. SP Group says 'global energy market.' Singapore is supposed to have one of the most efficient grids in the world. The pricing volatility being passed straight through to consumers feels lazy.",
        ],
    },
    "civil_service": {
        "weight": 0.06,
        "trend": "steady",
        "subjects": [
            "ICA appointment availability",
            "IRAS response time — query unanswered",
            "Town council responsiveness",
            "CPF withdrawal process feedback",
            "Compliment for staff at {town} CC",
        ],
        "bodies": [
            "Trying to book an ICA appointment for my child's passport. Earliest slot is 7 weeks away. We have a confirmed trip in 5 weeks. The walk-in option no longer exists. What are families supposed to do?",
            "Submitted a query to IRAS via the portal 18 working days ago. SLA is 5 working days. No acknowledgement, no holding response, nothing. The portal shows 'in progress.' Please follow up — case ref redacted in this email.",
            "Wanted to compliment Mr Tan at the {town} CC. Helped my elderly father with the LifeSG app patiently for almost an hour. This is the kind of public service that builds trust. Please pass on the thanks.",
            "CPF withdrawal at 65. Online process was actually smooth. Documents clear, no surprise queries. Money in my account in 4 working days. Credit where due.",
            "I've been emailing the town council for 6 weeks about a faulty drainage cover. Three different officers have replied with 'we'll look into this.' Today I called and was told 'no record found.' Where is the accountability?",
        ],
    },
    "community": {
        "weight": 0.05,
        "trend": "falling",
        "subjects": [
            "RC event feedback",
            "Community garden suggestion",
            "PA programme registration glitch",
            "Senior activity centre — programme requests",
            "Volunteer recognition",
        ],
        "bodies": [
            "Attended the RC Vesak Day event at our block. Well-organised, good turnout, food was generous. Just a note — please rotate the volunteer pool. Same 4 aunties always doing setup and teardown.",
            "Could we have a community garden plot at {town}? There's an unused grass patch next to Block {blk}. Several neighbours have expressed interest. Happy to coordinate if there's a process to request.",
            "PA registration page froze when I tried to book the cooking class. Tried Chrome, Firefox, Edge. Each time a different error. Eventually phoned and was told 'class full.' Annoying when the website never confirmed.",
            "The senior activity centre at {town} is great but the programmes are heavily mahjong-focused. Could we get more variety? Brisk walking groups, gardening, simple tech classes for seniors. I asked 12 friends — there's demand.",
            "I want to nominate Mr Raju, our block's RC chairman, for some form of recognition. He's been doing this for 11 years, knows every elderly resident by name, organises informal welfare checks. Quiet, consistent service.",
        ],
    },
    "employment": {
        "weight": 0.04,
        "trend": "steady",
        "subjects": [
            "WSG SkillsFuture course quality",
            "Foreign worker EP renewal experience",
            "Workfare payment delay",
            "MOM workplace complaint — outcome",
            "Career conversion programme feedback",
        ],
        "bodies": [
            "Completed a SkillsFuture course on data analytics. Subsidised. The content was 5 years out of date — no mention of GenAI tools at all in 2026. Trainer was reading slides verbatim. We need quality control on this funding.",
            "Going through EP renewal for our domestic helper. MOM portal asks for documents we've already uploaded. Process is opaque — no status visibility. This is stressful for both employer and helper.",
            "My Workfare payment is 6 weeks late. Hotline says 'processing.' I rely on this. Please check on this with urgency.",
            "Filed a workplace harassment complaint with MOM 4 months ago. Got an outcome letter saying 'closed, no further action.' No interview, no investigation summary. How is this 'closed'?",
            "Completed the PCP for tech sales transition. Honest feedback — the structured learning was solid but the employer placement was weak. I ended up at a company that didn't really know what to do with me. Coaching component needs strengthening.",
        ],
    },
    "kudos_general": {
        "weight": 0.04,
        "trend": "steady",
        "subjects": [
            "Just wanted to say thanks",
            "Singapore did good — feedback",
            "Suggestion: smart traffic lights",
            "Random observation about MRT",
            "Compliment to LTA team",
        ],
        "bodies": [
            "Sometimes I forget to say this — overall, Singapore works. Trains mostly run, bins get emptied, parks are clean, healthcare is accessible. I complain about specifics but the baseline is genuinely high. Thank you to the people who keep it that way.",
            "Caught myself appreciating something today — the air-con on the MRT was working perfectly during a heat wave outside. Small thing. Thanks.",
            "Suggestion — could we trial AI-adjusted traffic lights at {town} junction? The fixed cycles cause unnecessary waits at 11pm when there's no traffic. Other cities have done this.",
            "I want to recognise the LTA team handling the {line} line. The recovery from the signal fault last Friday was swift and the communication via SMS was clearer than usual. Better. Keep going.",
        ],
    },
}

TOWNS = ["Punggol", "Tampines", "Jurong East", "Ang Mo Kio", "Sengkang", "Woodlands",
         "Bedok", "Bukit Panjang", "Choa Chu Kang", "Toa Payoh", "Yishun", "Hougang",
         "Pasir Ris", "Bukit Batok", "Clementi", "Serangoon"]
LINES = ["East-West", "North-South", "North-East", "Circle", "Downtown", "Thomson-East Coast"]
STREETS = ["Tampines Ave 5", "Bukit Panjang Ring Rd", "Hougang Ave 8", "Jurong East St 13",
           "Sengkang Central", "Yishun Ave 2", "Ang Mo Kio Ave 3", "Bedok Reservoir Rd"]
BUS_NUMBERS = ["27", "133", "67", "85", "12", "151", "76", "168", "190", "53"]

def render(template, week_in_window):
    return (template
            .replace("{town}", random.choice(TOWNS))
            .replace("{line}", random.choice(LINES))
            .replace("{street}", random.choice(STREETS))
            .replace("{blk}", str(random.randint(100, 850)))
            .replace("{bus_no}", random.choice(BUS_NUMBERS))
            .replace("{phone}", "+65 9" + "".join(str(random.randint(0,9)) for _ in range(7))))

def pick_cluster(week_idx):
    """Pick a cluster, biased by its trend and the week index."""
    adjusted = {}
    for name, c in CLUSTERS.items():
        w = c["weight"]
        if c["trend"] == "rising":
            w *= (0.6 + 0.1 * week_idx)
        elif c["trend"] == "falling":
            w *= (1.4 - 0.1 * week_idx)
        adjusted[name] = w
    total = sum(adjusted.values())
    r = random.uniform(0, total)
    acc = 0
    for name, w in adjusted.items():
        acc += w
        if r <= acc:
            return name
    return name

def generate():
    emails = []
    start = ANCHOR - timedelta(weeks=WEEKS)
    for i in range(TOTAL_EMAILS):
        week_idx = random.choices(range(WEEKS), weights=[1, 1, 1.2, 1.2, 1.4, 1.5, 1.7, 2.0])[0]
        day_offset = random.uniform(0, 7)
        hour = random.choices(range(24), weights=[1]*6 + [3]*4 + [5]*4 + [4]*4 + [3]*4 + [2]*2)[0]
        minute = random.randint(0, 59)
        received_at = start + timedelta(weeks=week_idx, days=day_offset, hours=hour - 9, minutes=minute)

        cluster_name = pick_cluster(week_idx)
        cluster = CLUSTERS[cluster_name]

        subject = render(random.choice(cluster["subjects"]), week_idx)
        body = render(random.choice(cluster["bodies"]), week_idx)

        sender_name = random.choice(NAMES)
        if sender_name == "Anonymous":
            from_field = "anonymous@feedback.gov.sg"
            sender_display = "Anonymous"
        else:
            handle = sender_name.lower().replace(" ", ".")
            from_field = f"{handle}@example.com"
            sender_display = sender_name

        emails.append({
            "id": f"FB-{i+1:05d}",
            "received_at": received_at.isoformat(),
            "from_name": sender_display,
            "from_email": from_field,
            "subject": subject,
            "body": body,
            "channel": random.choices(["email", "web_form", "whatsapp_bot"], weights=[6, 3, 1])[0],
        })

    emails.sort(key=lambda e: e["received_at"])
    return emails

if __name__ == "__main__":
    data = generate()
    print(json.dumps(data, ensure_ascii=False, indent=2))
